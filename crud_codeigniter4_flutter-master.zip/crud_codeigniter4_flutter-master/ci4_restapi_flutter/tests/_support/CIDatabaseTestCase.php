<?php

use CodeIgniter\Test;

class CIDatabaseTestCase extends Test\CIDatabaseTestCase
{

}
